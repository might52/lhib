package org.jpwh.stateful;

public interface ItemService extends RemoteItemService{
    // Methods that are only available locally are here
}
