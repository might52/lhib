package org.jpwh.stateless;

public interface AuctionService extends RemoteAuctionService {
    // Methods that are only available locally are here
}
