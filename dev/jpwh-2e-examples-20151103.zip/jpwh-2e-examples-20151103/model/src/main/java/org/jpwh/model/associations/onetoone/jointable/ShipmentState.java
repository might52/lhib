package org.jpwh.model.associations.onetoone.jointable;

public enum ShipmentState {

    TRANSIT,
    CONFIRMED

}
